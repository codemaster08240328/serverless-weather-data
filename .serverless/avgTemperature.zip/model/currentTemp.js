"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var db_1 = __importDefault(require("./db"));
var curTempSchema = new db_1.default.Schema({
    name: {
        type: String,
        required: true,
    },
    time: {
        type: Date,
        required: true,
    },
    timezone: {
        type: Number,
        required: true,
    },
    temp: { type: Number, required: true },
    feels_temp: { type: Number, required: true },
    temp_min: { type: Number, required: true },
    temp_max: { type: Number, required: true },
    id: { type: Number, required: true },
});
exports.default = db_1.default.model('CurTemp', curTempSchema);
